# Photo Editor MVP (Flutter)

This is the first starter version of the Premium Black & Gold Android photo editor.

## Included
- Pick a photo from the device gallery
- Live brightness adjustment
- Rotate preview
- Save the edited preview as PNG inside the app's documents folder
- Share the saved PNG
- Beauty tab placeholder (real AI face enhancement is NOT connected yet)

## Requirements
- Flutter SDK (stable)
- Android Studio or VS Code
- Android SDK

## Run
1. Extract this ZIP.
2. Open a terminal in this folder.
3. Run `flutter create .` if platform folders are missing.
4. Run `flutter pub get`.
5. Connect an Android phone with USB debugging enabled.
6. Run `flutter run`.

## Build APK
`flutter build apk --release`

The APK will be at:
`build/app/outputs/flutter-apk/app-release.apk`

## Important
This is a starter source project, not a compiled APK. The Beauty control is currently a placeholder and does not perform AI face retouching. Saving captures the visible preview, so it includes the displayed brightness and rotation. The image is saved in the app's private documents folder; use Share to send it elsewhere.

Before Play Store release, add app icon, privacy policy, permission/data disclosures, testing, and current Google Play target API compliance.
