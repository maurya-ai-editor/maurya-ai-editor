import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const MauryaEditorApp());

const gold = Color(0xFFD6AD55);
const bg = Color(0xFF090909);
const panel = Color(0xFF171717);

class MauryaEditorApp extends StatelessWidget {
  const MauryaEditorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Photo Editor',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: gold,
          surface: panel,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: gold,
          thumbColor: gold,
          inactiveTrackColor: Color(0xFF555555),
        ),
      ),
      home: const EditorHome(),
    );
  }
}

class EditorHome extends StatefulWidget {
  const EditorHome({super.key});

  @override
  State<EditorHome> createState() => _EditorHomeState();
}

class _EditorHomeState extends State<EditorHome> {
  final picker = ImagePicker();
  final GlobalKey previewKey = GlobalKey();
  File? photo;
  double brightness = 0;
  double beauty = 0;
  double rotation = 0;
  bool showBeauty = false;
  bool busy = false;

  Future<void> choosePhoto() async {
    try {
      final file = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
      );
      if (file != null) {
        setState(() {
          photo = File(file.path);
          brightness = 0;
          beauty = 0;
          rotation = 0;
        });
      }
    } catch (e) {
      message('फोटो नहीं खुल सकी: $e');
    }
  }

  void message(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value), backgroundColor: panel),
    );
  }

  Future<Uint8List?> renderPreview() async {
    final boundary = previewKey.currentContext?.findRenderObject()
        as RenderRepaintBoundary?;
    if (boundary == null) return null;
    final ui.Image image = await boundary.toImage(pixelRatio: 2.5);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data?.buffer.asUint8List();
  }

  Future<void> savePhoto({bool share = false}) async {
    if (photo == null || busy) return;
    setState(() => busy = true);
    try {
      final bytes = await renderPreview();
      if (bytes == null) throw Exception('Preview unavailable');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(
        '${dir.path}/maurya_edit_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(bytes);
      if (share) {
        await Share.shareXFiles([XFile(file.path)], text: 'Edited with Photo Editor');
      } else {
        message('फोटो ऐप में सेव हो गई: ${file.path}');
      }
    } catch (e) {
      message('Save नहीं हो पाया: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  List<double> get brightnessMatrix {
    final b = brightness;
    return <double>[
      1, 0, 0, 0, b,
      0, 1, 0, 0, b,
      0, 0, 1, 0, b,
      0, 0, 0, 1, 0,
    ];
  }

  Widget toolButton(IconData icon, String label, VoidCallback action,
      {bool selected = false}) {
    return InkWell(
      onTap: action,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 88,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: selected ? gold.withOpacity(.15) : panel,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? gold : Colors.white10,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: gold, size: 23),
            const SizedBox(height: 6),
            Text(label, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        titleSpacing: 18,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PHOTO EDITOR',
                style: TextStyle(
                    color: gold, fontWeight: FontWeight.w800,
                    letterSpacing: 2, fontSize: 17)),
            Text('Premium editing studio',
                style: TextStyle(color: Colors.white54, fontSize: 10)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Reset',
            onPressed: photo == null
                ? null
                : () => setState(() {
                      brightness = 0;
                      beauty = 0;
                      rotation = 0;
                    }),
            icon: const Icon(Icons.restart_alt, color: gold),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: panel,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: gold.withOpacity(.28)),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: photo == null
                      ? _emptyState()
                      : RepaintBoundary(
                          key: previewKey,
                          child: Container(
                            color: const Color(0xFF101010),
                            alignment: Alignment.center,
                            child: ColorFiltered(
                              colorFilter: ColorFilter.matrix(brightnessMatrix),
                              child: Transform.rotate(
                                angle: rotation,
                                child: Image.file(
                                  photo!,
                                  fit: BoxFit.contain,
                                  width: double.infinity,
                                  height: double.infinity,
                                ),
                              ),
                            ),
                          ),
                        ),
                ),
              ),
            ),
            if (photo != null) _controls(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: choosePhoto,
                      icon: const Icon(Icons.add_photo_alternate_outlined),
                      label: const Text('Choose Photo'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: gold,
                        side: const BorderSide(color: gold),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: photo == null || busy
                          ? null
                          : () => savePhoto(),
                      icon: busy
                          ? const SizedBox(
                              width: 16, height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.save_alt),
                      label: Text(busy ? 'Saving...' : 'Save Photo'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: gold,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState() => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.photo_camera_back_outlined, color: gold, size: 58),
              SizedBox(height: 16),
              Text('Your creativity starts here',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Choose a photo to begin editing',
                  style: TextStyle(color: Colors.white54)),
            ],
          ),
        ),
      );

  Widget _controls() => Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        color: bg,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('EDIT TOOLS',
                style: TextStyle(
                    color: gold, fontWeight: FontWeight.bold,
                    letterSpacing: 1.5, fontSize: 11)),
            const SizedBox(height: 10),
            SizedBox(
              height: 78,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  toolButton(Icons.light_mode_outlined, 'Brightness',
                      () => setState(() => showBeauty = false),
                      selected: !showBeauty),
                  const SizedBox(width: 8),
                  toolButton(Icons.face_retouching_natural, 'Beauty',
                      () => setState(() => showBeauty = true),
                      selected: showBeauty),
                  const SizedBox(width: 8),
                  toolButton(Icons.rotate_right, 'Rotate',
                      () => setState(() => rotation += 1.5708)),
                  const SizedBox(width: 8),
                  toolButton(Icons.share_outlined, 'Share',
                      () => savePhoto(share: true)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Text(
                    showBeauty ? 'Beauty preview (soft enhancement)' : 'Brightness',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
                Text(
                  showBeauty
                      ? '${(beauty * 100).round()}%'
                      : '${(brightness * 100).round()}%',
                  style: const TextStyle(color: gold, fontSize: 12),
                ),
              ],
            ),
            Slider(
              value: showBeauty ? beauty : brightness,
              min: showBeauty ? 0 : -0.35,
              max: showBeauty ? 1 : 0.35,
              onChanged: (v) => setState(() {
                if (showBeauty) {
                  beauty = v;
                } else {
                  brightness = v;
                }
              }),
            ),
            if (showBeauty)
              const Text(
                'Note: Beauty control is a visual placeholder in this first version. Real AI face retouching will be added in Phase 2.',
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
          ],
        ),
      );
}
